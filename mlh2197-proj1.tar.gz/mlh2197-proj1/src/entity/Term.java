package entity;

public class Term {

	public String term;
    public Double weight;
    
    public Term(String term, Double weight) {
		super();
		this.term = term;
		this.weight = weight;
	}
}
